#ifndef CALCULATE__H
#define CALCULATE__H

#include "io.h"
#define MAX_YEARS 100

void calculateGrowth(Investment *invp);

#endif